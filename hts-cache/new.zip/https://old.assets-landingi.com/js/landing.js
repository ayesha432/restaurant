$(document).ready(function(){var flash=$('#flash');if(flash.length>0){bootbox.alert(flash.html());}
$('#branding').css({'position':'static'});});